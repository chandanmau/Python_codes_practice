fruit = ["A", "B", "C", "D", "E"]
print(fruit)
print(type(fruit))
fruit[2] = "3"
fruit.append("K")
print(fruit)

if "l" in fruit:
    print("L is present")
else:
    print("L is not present")

fruits = ["apple", "banana", "cherry", "date"]
print(fruits[0])     # Outputs: apple
print(fruits[1:3])   # Outputs: ['banana', 'cherry']
#append to add new  element at the end 
fruits.append(60)
print(fruits)
#insert element at the particuler index 
fruits.insert(2,43)
print(fruits)
#add two lists
fruit.extend(fruits)
print(fruit)
#remove element by value
fruit.remove(43)
print(fruit)
#pop element at iindex  
fruit.pop(1) 
print(fruit)
#remove by indexing 
del fruit[1:4]

print(fruit)

fruit.sort()
print(fruits)