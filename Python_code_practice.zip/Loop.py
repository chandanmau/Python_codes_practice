
#for loop 
for i in range (1,12,4):
    print(i,"Flame")

list=["Apple","Tomato","potato","Sev"]

for j in list :
    print(j)


# while loop 
a=2
while i <101:
    print(i)
    i+=1 

x = 4
y = 0
while x >= 1:  # Modify the loop condition to terminate properly
    x -= 1
    y += 1

if x == y:  # After the loop finishes, compare x and y
    print(x, y)  # This will print x and y when the condition is met





 