list = [20, 30, 54, 54, 43, 234, 5]

# Swapping elements at index 1 and 3
list[1], list[3] = list[3], list[1]

print(list)

####solve using loop
# Indices to swap
index1 = 1
index2 = 3

# Loop to swap the elements
for i in range(len(list)):
    if i == index1:
        temp = list[index1]
        list[index1] = list[index2]
        list[index2] = temp
        break  # Exit the loop after swapping

print(list)


#take input from user and change elememts basis of index 

n=int(input("Enter the  n:"))

list=[]
for _ in range(n):
    num=int(input())
    list.append(num)

idx1= int(input("Enter 1"))
idx2= int(input("Enter 2"))

temp=list[idx1]
list[idx1]=list[idx2]
list[idx2]=temp

print(list)