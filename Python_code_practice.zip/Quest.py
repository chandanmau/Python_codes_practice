
#finding vol of sphere with radius 
# num1=int(input("Enter the radius"))
# volume=(4/3*3.14*num1**3)
# print("volume",volume)

#farenhite to celcius 
celcius=float(input("enter the temp"))
faren=(celcius*9/5)+32
print("faren temp",faren)

