#find the col elememt from three list set
l1=[32,43,54,64,65,67]
l2=[32,43,54,64,60,67]
l3=[32,41,54,65,65,67]

#typecasting into sets 
s1=set(l1)
s2=set(l2)
s3=set(l3)

s1s2=s2.intersection(s1)
final_set=s1s2.intersection(s3)
final_list=list(final_set)
print(final_list)

