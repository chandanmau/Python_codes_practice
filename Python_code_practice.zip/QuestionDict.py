# Take input from the user
input_string = input("Enter a string: ")
n = int(input("Enter a position (n): "))

# Define the alphabet and its reversed counterpart
alphabets = "abcdefghijklmnopqrstuvwxyz"
reverse_alphabet = alphabets[::-1]  # Reverse the alphabet

# Create a dictionary to map each letter to its mirrored counterpart
dict1 = dict(zip(alphabets, reverse_alphabet))

# Validate the input position
if 1 <= n <= len(input_string):
    # Split the string into prefix and suffix
    prefix = input_string[:n - 1]  # Characters before the nth position
    suffix = input_string[n - 1:]  # Characters from the nth position onward

    # Mirror the suffix using a for loop
    mirrored_suffix = ""
    for char in suffix:
        if char in dict1:
            mirrored_suffix += dict1[char]  # Get the mirrored character
        else:
            mirrored_suffix += char  # Keep the character as is if not in the dictionary

    # Combine the prefix and mirrored suffix
    result = prefix + mirrored_suffix

    print("Result:", result)
else:
    print("Invalid position. Please enter a number between 1 and the length of the string.")
