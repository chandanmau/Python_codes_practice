#factorial using recurssion
def factorial(n):
    #base case
    if n==0:
        return 1
    #recursive case 
    ans=n *factorial(n-1)
    return ans

n=int(input("Enter the n:"))
print(factorial(n))

#write a program to print number n to 1 
def ntoone(n):
    #base case 
    if n==0:
        return
    print(n) # print n to 1
    #recursive  case 
    ntoone(n-1)
    print(n)#print 1 to n

ntoone(7)


#write a print from  1 to n
def sum_to_1(n):
    #base case 
    if n==1:
        return 1
    #recursive 
    ans= n+ sum_to_1(n-1)
    return ans

n=int(input("entern n:"))
print (sum_to_1(n))


# finding a ke power b using recursion 
def power(a, b):
    # Base case: anything raised to the power of 0 is 1
    if b == 0:
        return 1
    # Recursive case
    ans=a * power(a, b - 1)
    return ans

# Taking input from the user
a = int(input("Enter the base (a): "))
b = int(input("Enter the exponent (b): "))

# Calculating and displaying the result
result = power(a, b)
print(f"{a} raised to the power {b} is: {result}")

     
    
    