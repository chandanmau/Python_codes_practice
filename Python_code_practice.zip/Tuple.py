fruit=("a","s","d")
card=("e",)

print(type(card))

print(fruit[0])#positive indexing 
print(fruit[-1])#negative indexing 

print(fruit[1:2])#range indexing 

if "a" in fruit:
    print("a is present")
else:
    print("a is not present ")

#traverse the tupple 
for i in fruit:
    print(i)    

fruits=("apple","orange","grapes","guava")
new_fruits=fruit+fruits
print(new_fruits)

input_tuple=(1,2,3,4,5,6)
list=[]
for x in reversed (input_tuple):
    list.append(x)

output_tuple=tuple(list)
print(output_tuple)
print(type(output_tuple))