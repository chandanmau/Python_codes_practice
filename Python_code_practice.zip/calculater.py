num1=int(input("Enter num1:"))
num2=int(input("Enter num2:"))

operator=input("enter operator")
match operator :
    case"+":
        print("sum is",num1+num2)
    case"-":
        print("subtraction is",num1-num2)
    case"*":
        print("multiplication is ",num1*num2)
    case"/":
        print("division is ",num1/num2)
    case _:
        print("Enter valid no")
    
    
