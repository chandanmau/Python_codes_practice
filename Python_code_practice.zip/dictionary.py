Info = {
    "name": "Ram",
    "sex": "male",
    "wife": "Ritika",
    "babies": 3
}

print(Info)
print(type(Info))
print(len(Info))
print(Info["wife"])
print(Info.keys)
Info["sex"]="female"
print(Info)

#add more info
more_info={
    "roy":345,
    "san": 400

}

Info.update(more_info)
print(Info)

#remove elememt in the dict 
Info.pop("roy")
print(Info)

#this will empty the dict 
# Info.clear()
# print(Info)

for x in Info:
    print(Info)
    print(Info[x])

#printing values of a dict

for x,y in Info.items():
    print(x,y)


phones = {
    "area1": {
        "A": 23,
        "B": 56,
        "y": 45
    },
    "area2": {
        "A": 83,
        "B": 54,
        "y": 65
    }
}

print(phones["area2"]["A"])  # Accessing the value of "A" in "area2"

