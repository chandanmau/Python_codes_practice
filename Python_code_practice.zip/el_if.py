num1=int(input("Enter the number"))
if num1>0:
    print("no. if positive")
else:
    print("no is negative")


num=int(input("Enter the number"))

if num %2 ==0:
    print("no is even")
else:
    ("print no is odd ")    



#profit loss
cp=int(input("Enter the cp"))
sp=int(input("Enter the sp"))

if cp>sp:
    print("Loss" ,cp-sp)
elif cp<sp:
    print("profit",sp-cp)
else:
    print("no profit no gain")
      








marks = int(input("Enter the marks: "))

if 80 < marks <= 100:
    print("Very good")
elif 60 < marks <= 80:
    print("Good")
elif 40 < marks <= 60:
    print("Average")
else:
    print("Fail")


