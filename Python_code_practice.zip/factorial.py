# Function to calculate the factorial
def factorial(n):
    result = 1
    for i in range(1, n + 1):
        result *= i
    return result

# Input from the user
number = int(input("Enter a positive number: "))

# Check if the number is positive
if number < 0:
    print("Factorial is not defined for negative numbers.")
else:
    # Call the factorial function and print the result
    print(f"The factorial of {number} is {factorial(number)}")
