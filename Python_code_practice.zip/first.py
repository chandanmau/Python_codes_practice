print("hello")
char = "a"
cha = " "
ch = "A"

ascii = "67"

# Convert the string 'ascii' to an integer before passing to chr()
print(chr(int(ascii)))  # This will print the character corresponding to ASCII code 67

print(ord(ch))  # ASCII value of 'A' (65)
print(ord(cha))  # ASCII value of space (' ') (32)
print(ord(char))  # ASCII value of 'a' (97)
