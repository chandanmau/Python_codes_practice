def sum(n, n1):
    sum = n + n1
    return sum

x = 6
y = 7
ans = sum(x, y)
print(ans)

# Correctly calling the sum function with new arguments
n = 22
n1 = 43
result = sum(n, n1)
print("The sum is", result)

#arbitary arguments
def addallnum(*args):  # Use *args to accept a variable number of arguments
    sum = 0
    for i in args:
        sum += i
    return sum

output = addallnum(2, 3, 4, 5, 6, 7, 8)  # Correct function call
print("The sum is", output)  # Fixed syntax for the print statement


def student_info(**kwargs):
    for x,y in kwargs.items():
        print(x ,("is"), y)

student_info(nmae ="urvi",age="4",gender="F")        
student_info(nmae ="urdi",age="2",gender="M")        
student_info(nmae ="ura",age="8",gender="F")        
