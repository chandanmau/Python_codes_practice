fname=input("Enter the name")
Lname=input("Enter last name")

print(fname,Lname)

num1=int(input("enter f num"))
num2=int(input("enter s num "))
print(type(num1))
sum=(num1+num2)
print(sum)



#operators

n1=5
n2=n1
print(n1,n2)
n2+=n1
print(n1,n2)
n2-=n1
print(n1,n2)
n2*=n1
print(n1,n2)

#comparison operator 

a1 = 3
a2 = 4

print(a1 == a2)  # Checks if a1 is equal to a2
print(a1 != a2)  # Checks if a1 is not equal to a2



a=5
b=5
print("if a is b ",a is b)