
a=5
b=5
print("if a is b ",a is b)

c=["cow","dog","apple"]
print("apple is present in c ", "apple" in c )


#bitwise opertor
a1=2
a2=3
print("a  and b ",a&b)
print("a  or b ",a|b)
print("a  Zor b ",a^b)