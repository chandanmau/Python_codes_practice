#pass by values
def addone(x):
    x=x+1
    print("inside function",x)


x=5
addone(x)
print("outside function",x)   

#pass by references

def modifylist(lst):
    lst.append(4)
    print("inside fn",lst)


lst=[1,2,3,4,5,5]
modifylist(lst)
print("outside fn",lst)    
