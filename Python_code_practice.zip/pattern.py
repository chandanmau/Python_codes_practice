#n = int(input("Enter n: "))  # Prompt the user for input and convert it to an integer

# for _ in range(n):  # Loop n times
#     print("*" * 5)  # Print 5 stars each time




n = int(input("Enter n: "))

for i in range (n):  
    for j in range (1,n+1):
        print(j,end="")
    print()

n = int(input("Enter n: "))
for i in range (1 ,n+1):
    for j in range(1,i+1):
        print(j,end="")
    print()    



n = int(input("Enter n: "))

for i in range(1, n+1):
    # Print leading spaces for alignment
    print(" " * (n - i), end="")  
    
    # Print numbers with a space between each
    for j in range(1, i + 1):
        print(j, end=" ")
    
    # Move to the next line
    print()
   
