eng_mar=int(input("Enter english marks:"))
math_mar=int(input("enter maths marks"))

if eng_mar>80 and math_mar>80:
    print("Excellent")
elif eng_mar>80 or math_mar>80:
    print("Good")
else:
    print("avergae")   

#four digit number 
number=int(input("Enter the 4 digit  number"))

if 1000 < number >9999:
    print("num is 4 digit")
else:
    print("num is not 4 digit")    