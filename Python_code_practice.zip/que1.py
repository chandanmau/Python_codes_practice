# num1=int(input("Enter num1:"))
# num2=int(input("Enter num2:"))
# num3=int(input("Enter num3:"))

# if num1>num2 and num1>num3:
#     print("num1 is the gratest")
# elif num2>num1 and num2>num3:
#     print ("num2 is the largest")
# else :
#     print("num3 is largest num ")    


num=int(input("enter the num"))
if num % 15==0 :
    print("num is divisible by 15")  
else:
    if num%5==0 or num%3==0:
        print("num is divisible by 5 or 3 not 15 ")     