names={"sia","pia","kia","lia"}
print(type(names))

for x in names:
    print(x)

if "sia" in names:
    print("name is present ")

names.add("fia")# add new element duplicate not allowed 
print(names)        
#add another seq in set 
list_names=["ria","kia"]
names.update(list_names)
print(names)


names.remove("kia")
print(names)

names.discard("jia")# discard fn do not throw error if element is absent in the set 
print(names)

#joining two set 
s1={'1','2','5','3','4','5'}
s3={'a','b','g','g','e','l'}

s2=s1.union(s3)
print(s2)

#keep only duplicate while joining
s1.intersection_update(s3)
print(s1)
#keep all  values except duplicate 
s1.symmetric_difference_update(s2)
print(s1)