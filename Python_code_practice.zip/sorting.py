list=[20,30,24,53,56,65]

list.sort()
print(list)
list.sort(reverse=True)
print(list)
list.reverse()
print(list)

lists = [20, 30, 24, 53, 56, 65]

# Create a copy of the list to iterate over, and append to the original list
for i in list.copy():  # Iterate over the copy of the list
    if i > 20:
        list.append(i)

print(list)  # The list will now have the elements greater than 20 appended

list = [5, 12, 20, 8, 30, 4, 15]

newlist = [i for i in list if i > 10]
print(newlist)

newlists=list.copy()
print(newlists)

New=list+newlist
print(New)

#insert list in list 
New.insert(2,[1,2,3])
print(New)
