#concatenation 
str1="hello world"
str2="what a great place to play "
print(str1+str2)


#format fn used to insert variable values in a string 
fruit="mango"
fruit2="guava"
rate=45
str="thename of gruit is {s},and rate is {m}".format(s=fruit,m=45)
print(str)

print(fruit.find('g'))# it will give at which index the element 
print(str[:10])
print(str.replace('gruit','never'))