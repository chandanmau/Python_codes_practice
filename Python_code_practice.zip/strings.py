name="sanjeev"
print(name[0])

for i in name:
    print(i)

#using list comprehension 
list=[char for char in name] 
for i in name:
    print(i)   




# Example string
text = "Hello, Python!"

# Slicing examples
print(text[0:5])  # Output: 'Hello' (characters from index 0 to 4)
print(text[7:13]) # Output: 'Python' (characters from index 7 to 12)
print(text[:5])   # Output: 'Hello' (from start to index 4)
print(text[7:])   # Output: 'Python!' (from index 7 to end)
print(text[-7:-1]) # Output: 'Python' (negative indexing)

# Step slicing
print(text[::2])  # Output: 'Hlo yhn' (every second character)



# for char to uppercase

school="flame"
st1=school.upper()    
print(st1)
st2=school.lower()
print(st2)

st3=school.capitalize()
print(st3)

#for stripping or removing white spaces 

fruit="apple  is good"
print(fruit.strip())

# replace old with new substring 
s="hello i am sanjeev, ug3"
print(s.replace("sanjeev","Akku"))

# split fn  used to split into list of substrings
ss = "apple_banana_mango"
splt = ss.split("_")  # Splits the string based on underscores
print(splt)

