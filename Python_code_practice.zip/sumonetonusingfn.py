# Writing a function for calculating the sum from 1 to n
def sumOneToN(n):
    sum = 0
    for i in range(1, n + 1):
        sum += i
    return sum

# Taking input from the user
n = int(input("Enter n: "))

# Calling the function
output = sumOneToN(n)

# Displaying the result
print("Sum of all numbers till n is", output)




# Nested function example
def outer_function():
    x = 1  # Variable in the outer function

    def inner_function():
        y = 2  # Variable in the inner function
        result = x + y
        return result

    return inner_function()

# Calling the outer function
output = outer_function()
print(output)
